# FinTrack AI — React + Node + Python ML

FinTrack is a full-stack personal-finance and machine-learning project designed for an FAI (Foundations of Artificial Intelligence) demonstration.

## Technology stack

- **Frontend:** React 18, Vite, Recharts, Lucide React, responsive CSS
- **Backend:** Node.js 18+ and Express
- **Machine learning:** Python, scikit-learn, NumPy
- **Storage:** account-separated local JSON store (`data/fintrack.json`)
- **Optional generative AI:** OpenAI API through the backend only

## Features

- Email/password registration and login; salted scrypt password hashes and HttpOnly session cookie
- Income and expense entry, category summaries, transaction deletion and JSON export
- Monthly budgets and budget progress
- Savings goals and contributions
- Six-month income/expense area chart, category donut chart and AI forecast comparison chart
- Responsive React dashboard with overview, transactions, budgets, savings goals, AI intelligence and assistant screens
- Per-account data isolation on the existing Express API

## AI/ML features (actual scikit-learn models)

1. **Expense title categorisation — TF-IDF + Logistic Regression:** vectorises transaction descriptions and predicts an expense category with confidence. Starts with synthetic labelled examples and incorporates the signed-in user's labelled examples when enough exist.
2. **Expense forecasting — Random Forest Regressor:** predicts category-level next-month expenses using three monthly lags, income, category and time features. Evaluated against a three-month-average baseline using held-out synthetic users. Personal history is added to the final fit; a personal forecast is displayed only with at least three distinct expense months.
3. **Unusual-spend screening — Isolation Forest:** flags selected unusual expense patterns for human review. It is not a fraud detector.
4. **Spending segmentation — K-Means:** clusters category-share profiles and describes the dominant spending pattern.
5. **Adaptive budget suggestions:** recent personal category average plus 5%. This is an explicit arithmetic rule, not a trained ML model.

The AI assistant uses the optional OpenAI API if configured; otherwise, it falls back to a local rule-based finance assistant. The chatbot is separate from the scikit-learn models.

## Run locally (Ubuntu / VS Code)

Open the extracted project root — the folder containing `package.json`, `server.js`, and `ml/`.

### 1. Install Python dependencies

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r ml/requirements.txt
```

### 2. Install JavaScript dependencies and build React

```bash
npm install
npm run build
```

### 3. Start the backend

```bash
npm start
```

Open **http://localhost:5000**. Create an account or sign in. The Express server serves the built React frontend from `dist/` and serves the existing API. The ML endpoint automatically uses `.venv/bin/python` when the project virtual environment exists, even if you start Node from another terminal. You can override this with `PYTHON_BIN` if needed.

### Development mode

Use two terminals from the project root:

Terminal 1:
```bash
npm start
```

Terminal 2:
```bash
npm run dev
```

Open **http://localhost:5173**. Vite proxies `/api` requests to the Express server on port 5000.

## Optional OpenAI assistant

```bash
cp .env.example .env
```

Add `OPENAI_API_KEY` to `.env`, then restart the backend. The key remains server-side. Do not add it to React source files or commit `.env` to GitHub. Without a key, the local assistant remains available.

## Tests

```bash
node --check server.js
python3 -m py_compile ml/ml_engine.py
python3 ml/tests/smoke_test.py
npm run build
```

## Important academic limitations

- Synthetic holdout metrics are not proof of accuracy on a user's future spending. A proper research evaluation should use consented real-world data and a time-based held-out test set.
- Personal forecasting needs at least three distinct months of expenses and can be unstable with short histories.
- Synthetic training data are bootstrap data; the system is not pretrained on bank-grade transaction records.
- Isolation Forest flags are prompts for manual review, not fraud findings.
- No automatic bank or UPI integration exists. Never enter bank passwords, UPI PINs, card PINs or OTPs.
- The local JSON file is not encrypted. This is an educational prototype, not a production financial service or investment adviser.
